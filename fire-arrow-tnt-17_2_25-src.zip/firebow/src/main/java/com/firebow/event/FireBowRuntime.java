package com.firebow.event;

import com.firebow.util.ArrowLanding;
import com.firebow.util.AsyncRunner;
import com.firebow.util.InteractionUtil;
import com.firebow.util.InventoryUtil;
import com.firebow.util.PingUtil;
import com.firebow.util.PlacementCalc;
import com.firebow.util.RotationUtil;
import com.firebow.util.SearchResult;
import com.firebow.util.ShotPredictor;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * FireBowRuntime v20 — kích hoạt lúc THẢ CUNG, như BOOST-FPS.
 *
 *  1. onBowReleased: thả cung, có cung/arrow/rail/cart, lực ≥ 0.1 → dự đoán điểm rơi, tạo job NGAY.
 *     Không đổi slot lúc thả (gói RELEASE đã được gửi trước). Job chờ arrow xác nhận.
 *  2. job chạy như v19: SEND (rail) → CART (cart) → CONFIRM.
 *  3. requestRail (arrow xuất hiện): xác nhận. so điểm thật với dự đoán. nếu rail chưa đặt thì đổi điểm theo thật.
 *  4. arrow không tới trong deadline (ping + 8 tick) → bỏ job. rail/cart đã đặt không tự gỡ.
 *
 * Trường hợp không có release (ví dụ bắn qua cách khác) → fallback: tạo job khi arrow xuất hiện như v19.
 */
public final class FireBowRuntime {

    private static final Logger LOGGER = LoggerFactory.getLogger("firebow");

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    private static final long ARROW_TTL          = 3000L;
    private static final int  MAX_PLACE_ATTEMPTS = 4;
    private static final int  MAX_WAIT           = 20;
    private static final int  MAX_JOB_TICKS      = 120;
    private static final int  MAX_CONFIRM_TICKS  = 30;
    private static final int  MAX_ARROW_WAIT     = 25;
    private static final int  MAX_LAND_TICKS     = 40;

    private enum Phase { SEND, CART }

    private static final class RailJob {
        BlockPos pos;
        int   attempts    = 0;
        Phase phase       = Phase.SEND;
        int   ticks       = 0;
        int   totalTicks  = 0;
        boolean awaitingArrow = false;
        int   arrowDeadline   = 0;

        RailJob(BlockPos pos, int attempts) {
            this.pos      = pos;
            this.attempts = attempts;
        }
    }

    private static final class Confirm {
        final BlockPos pos;
        final int attempts;
        int ticksLeft;

        Confirm(BlockPos pos, int attempts, int ticksLeft) {
            this.pos       = pos;
            this.attempts  = attempts;
            this.ticksLeft = ticksLeft;
        }
    }

    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private final List<Confirm> confirms = new ArrayList<>();
    private final List<RailJob> retries = new ArrayList<>();
    private volatile boolean enabled = true;
    private RailJob job = null;
    private long releaseMs = 0L;

    private FireBowRuntime() {}

    public boolean isEnabled() { return enabled; }
    public void    toggle()    { enabled = !enabled; }
    public boolean isBusy()    { return job != null; }

    public boolean isDuplicateArrow(int id) {
        Long t = acceptedArrows.get(id);
        return t != null && (System.currentTimeMillis() - t) < ARROW_TTL;
    }

    // ─── 1. Thả cung: dự đoán và tạo job ngay ───────────────────────────────

    public void onBowReleased(ClientPlayerEntity p, int useTimeLeft) {
        if (!enabled) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.interactionManager == null) return;

        if (InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL).isMissing()) return;
        if (InventoryUtil.findItem(Items.TNT_MINECART).isMissing()) return;
        if (!p.isCreative() && InventoryUtil.findItem(Items.ARROW).isMissing()) return;

        ArrowLanding.Hit hit = ShotPredictor.predictRelease(p, useTimeLeft);
        if (hit == null || hit.ticks() > MAX_LAND_TICKS) return;

        // điểm dự đoán ngoài reach hoặc không có nền thì job sẽ treo, chặn các lượt sau: bỏ luôn
        BlockPos cartBlock = hit.cartBlock();
        if (!InteractionUtil.inReach(p, cartBlock)) {
            LOGGER.info("[firebow] bỏ release: điểm dự đoán {} ngoài reach", cartBlock);
            return;
        }
        if (!PlacementCalc.isSolidGround(mc.world, cartBlock.down())) {
            LOGGER.info("[firebow] bỏ release: không có nền dưới {}", cartBlock);
            return;
        }

        // job cũ chưa đặt gì thì thay bằng job mới; job đã đặt rail thì giữ nguyên
        if (job != null) {
            if (job.phase == Phase.SEND && !isRail(mc, job.pos)) {
                LOGGER.info("[firebow] thay job cũ {} bằng release mới {}", job.pos, cartBlock);
            } else {
                return;
            }
        }

        RailJob j = new RailJob(cartBlock, 0);
        j.awaitingArrow = true;
        long ping = PingUtil.getPingMs(mc);
        j.arrowDeadline = (int) Math.min(MAX_ARROW_WAIT, ping / 50L + 8L);
        job = j;
        releaseMs = System.currentTimeMillis();
    }

    // ─── HEAD tickMovement: arm góc nếu bước này sẵn sàng ───────────────────

    public void beforeMovement() {
        if (!enabled || job == null || RotationUtil.isActive()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;

        if (p.hurtTime > 0) return;   // đang bị đánh/knockback: không xoay, chờ hết hurt
        if (!stepReady(mc, p, job)) return;
        Vec3d hit = armTarget(mc, job);
        if (hit == null) return;

        float silentYaw = RotationUtil.snapToMouseGrid(p, RotationUtil.calcRotationFromEye(p.getEyePos(), hit))[0];
        if (!RotationUtil.movementSafe(p, silentYaw)) return;   // đang chạy mà xoay sẽ đổi phím → chờ

        RotationUtil.arm(p, hit);
    }

    private static boolean stepReady(MinecraftClient mc, ClientPlayerEntity p, RailJob j) {
        return switch (j.phase) {
            case SEND -> !isRail(mc, j.pos)
                    && !InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL).isMissing()
                    && InteractionUtil.railReady(mc, p, j.pos);
            case CART -> isRail(mc, j.pos)
                    && !InventoryUtil.findItem(Items.TNT_MINECART).isMissing()
                    && !cartPresent(mc, j.pos)
                    && InteractionUtil.cartReady(mc, p, j.pos);
        };
    }

    private static Vec3d armTarget(MinecraftClient mc, RailJob j) {
        return switch (j.phase) {
            case SEND -> isRail(mc, j.pos) ? null : RotationUtil.calcHitVec(j.pos.down(), Direction.UP);
            case CART -> isRail(mc, j.pos) ? RotationUtil.railHit(j.pos) : null;
        };
    }

    // ─── 3. Arrow xuất hiện: xác nhận, hoặc fallback nếu không có release ─────

    public void requestRail(MinecraftClient mc, int arrowId, BlockPos railPos) {
        if (job != null && job.awaitingArrow) {
            job.awaitingArrow = false;
            LOGGER.info("[firebow] arrow xuất hiện sau {} ms từ lúc thả", System.currentTimeMillis() - releaseMs);
            acceptedArrows.put(arrowId, System.currentTimeMillis());
            AsyncRunner.runDelayed(() -> acceptedArrows.remove(arrowId), ARROW_TTL);

            if (!job.pos.equals(railPos)) {
                if (job.phase == Phase.SEND && !isRail(mc, job.pos)) {
                    LOGGER.info("[firebow] đổi điểm đặt {} → {} (thật)", job.pos, railPos);
                    job.pos = railPos;
                } else {
                    LOGGER.info("[firebow] dự đoán {} khác điểm thật {} (rail đã đặt)", job.pos, railPos);
                }
            }
            return;
        }

        MinecraftClient m = mc;
        if (job != null) {
            if (!(job.phase == Phase.SEND && !isRail(m, job.pos))) return;
            LOGGER.info("[firebow] thay job treo {} bằng điểm thật {}", job.pos, railPos);
        }
        if (InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL).isMissing()) return;

        acceptedArrows.put(arrowId, System.currentTimeMillis());
        AsyncRunner.runDelayed(() -> acceptedArrows.remove(arrowId), ARROW_TTL);
        job = new RailJob(railPos, 0);
    }

    // ─── END_CLIENT_TICK ─────────────────────────────────────────────────────

    public void onClientTick(MinecraftClient mc) {
        try {
            if (mc.player == null || mc.world == null) {
                job = null;
                confirms.clear();
                retries.clear();
                RotationUtil.end(null);
                return;
            }

            tickConfirms(mc);

            if (!enabled) {
                if (job != null) abort();
                return;
            }

            if (job == null && !retries.isEmpty()) job = retries.remove(0);
            if (job != null) stepJob(mc);
        } finally {
            RotationUtil.end(mc.player);
        }
    }

    private void stepJob(MinecraftClient mc) {
        RailJob j = job;
        j.ticks++;
        j.totalTicks++;
        if (j.totalTicks > MAX_JOB_TICKS) { abort(); return; }

        if (j.awaitingArrow && j.totalTicks > j.arrowDeadline) {
            LOGGER.info("[firebow] không thấy mũi tên sau khi thả cung, bỏ job (rail/cart đã đặt có thể còn lại)");
            abort();
            return;
        }

        boolean railThere = isRail(mc, j.pos);

        switch (j.phase) {
            case SEND -> {
                if (railThere) { enter(j, Phase.CART); return; }
                if (!RotationUtil.isActive()) {
                    if (j.ticks > MAX_WAIT) abort();
                    return;
                }
                SearchResult rail = InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL);
                if (rail.isMissing()) { abort(); return; }

                switch (InteractionUtil.executeRail(mc, j.pos, rail.slot)) {
                    case SENT      -> { j.attempts++; enter(j, Phase.CART); }
                    case NOT_READY -> { if (j.ticks > MAX_WAIT) abort(); }
                    case INVALID   -> abort();
                }
            }

            case CART -> {
                if (!railThere) {
                    if (j.attempts >= MAX_PLACE_ATTEMPTS) abort();
                    else enter(j, Phase.SEND);
                    return;
                }
                if (cartPresent(mc, j.pos)) { job = null; return; }
                if (!RotationUtil.isActive()) {
                    if (j.ticks > MAX_WAIT) abort();
                    return;
                }
                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (cart.isMissing()) { abort(); return; }

                if (InteractionUtil.placeCartDirect(mc, j.pos, cart.slot)) {
                    LOGGER.info("[firebow] gửi cart sau {} ms từ lúc thả", System.currentTimeMillis() - releaseMs);
                    confirms.add(new Confirm(j.pos, j.attempts, verifyWindow(mc)));
                    job = null;
                } else if (j.ticks > MAX_WAIT) {
                    abort();
                }
            }
        }
    }

    private void tickConfirms(MinecraftClient mc) {
        for (int i = confirms.size() - 1; i >= 0; i--) {
            Confirm c = confirms.get(i);
            c.ticksLeft--;
            if (c.ticksLeft > 0) continue;

            confirms.remove(i);
            if (cartPresent(mc, c.pos)) {
                LOGGER.info("[firebow] cart spawn xác nhận tại {}", c.pos);
                continue;
            }
            LOGGER.info("[firebow] cart KHÔNG spawn tại {} (rail {})", c.pos, isRail(mc, c.pos) ? "còn" : "mất");
            if (!isRail(mc, c.pos) && c.attempts < MAX_PLACE_ATTEMPTS) {
                retries.add(new RailJob(c.pos, c.attempts));
            }
        }
    }

    private static void enter(RailJob j, Phase phase) {
        j.phase = phase;
        j.ticks = 0;
    }

    private static int verifyWindow(MinecraftClient mc) {
        long ping = PingUtil.getPingMs(mc);
        return (int) Math.min(MAX_CONFIRM_TICKS, ping / 50L + 4L);
    }

    private void abort() {
        job = null;
    }

    private static boolean cartPresent(MinecraftClient mc, BlockPos pos) {
        Box box = new Box(pos.getX(), pos.getY(), pos.getZ(),
                          pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1);
        return !mc.world.getEntitiesByClass(TntMinecartEntity.class, box,
                e -> e.getBlockPos().equals(pos)).isEmpty();
    }

    private static boolean isRail(MinecraftClient mc, BlockPos pos) {
        BlockState s = mc.world.getBlockState(pos);
        return s.isOf(Blocks.RAIL) || s.isOf(Blocks.POWERED_RAIL);
    }
}
